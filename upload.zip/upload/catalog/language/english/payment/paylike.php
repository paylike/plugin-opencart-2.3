<?php
// Text
$_['text_title'] = 'Credit Card (Paylike)';
$_['text_order_updated'] = 'Order updated';
$_['text_no_transaction_found'] = 'No transaction reference found';
$_['text_invalid_transaction'] = 'Invalid transaction';